import keyboard

class KeyboardExtension:
    def key_press(self, key):
        keyboard.send(key)
    def key_write(self, text):
        keyboard.write(text)
    def key_combo(self, combo):
        keyboard.send(combo)

ext = KeyboardExtension()

def load(runtime):
    runtime.register("key_press", ext.key_press)
    runtime.register("key_write", ext.key_write)
    runtime.register("key_combo", ext.key_combo)
