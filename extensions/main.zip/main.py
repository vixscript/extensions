# main.py for math extension
import math

def load(runtime):
    # basic arithmetic
    runtime.register("add", lambda a,b: a+b)
    runtime.register("sub", lambda a,b: a-b)
    runtime.register("mul", lambda a,b: a*b)
    runtime.register("div", lambda a,b: a/b)
    runtime.register("mod", lambda a,b: a%b)
    runtime.register("pow", lambda a,b: a**b)

    # math functions
    runtime.register("sqrt", math.sqrt)
    runtime.register("sin", math.sin)
    runtime.register("cos", math.cos)
    runtime.register("tan", math.tan)
    runtime.register("log", math.log)
    runtime.register("log10", math.log10)
    runtime.register("exp", math.exp)
    runtime.register("floor", math.floor)
    runtime.register("ceil", math.ceil)
    runtime.register("round", round)
    runtime.register("abs", abs)

    # constants
    runtime.register_value("PI", math.pi)
    runtime.register_value("E", math.e)
    runtime.register_value("TAU", math.tau)
    runtime.register_value("INF", math.inf)
    runtime.register_value("NAN", math.nan)
