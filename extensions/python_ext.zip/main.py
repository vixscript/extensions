# vixscript extention to interact with Python

def _python(code: str):
    try: # evaluate expression first
        result = eval(code, {}, {})
    except SyntaxError: # if not an expression, execute as a statement
        exec(code, {}, {})
        result = None
    return result

def load(runtime):
    runtime.register("python", _python)
